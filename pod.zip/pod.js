str [usage] {
	This is a sample script from WHOLE.js
	using pipe to open processes.
	
	Watch the application process while executed :
}
{
	
	return js.str.usage + ":::/" ;
}