{
	import {getcwd} from "os"
	return "Working dir : " + getcwd().str;
}